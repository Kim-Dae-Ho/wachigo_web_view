function modify(){
    let modifyArray = [];
    const number = $("#number").val();
    const name = $("#name").val();
    const info = $("#info").val();

    const data = {
        'number' : number,
        'name' : name,
        'info' : info
    };
    modifyArray.push(data);
    console.log(modifyArray);
    $.ajax({
        url      : "/modify",
        data     : JSON.stringify(modifyArray),
        type     : "POST",
        dataType:'text',
        contentType:'application/json;',
        success : function(result) {
            location.href = "/";
        },
        error:function(request,status,error){
            swal({
                text: "서버 문제로 수정하지 못했습니다.",
                icon: "warning" //"info,success,warning,error" 중 택1
            });
        }
    });
}