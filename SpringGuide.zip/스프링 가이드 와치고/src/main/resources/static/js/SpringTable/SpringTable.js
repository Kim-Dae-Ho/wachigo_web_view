// 페이지 번호 눌렀을 때
function paging(pageValue) {
    const myPageQuery = new URLSearchParams(location.search);
    var selectKey = $('#selectKey').val();
    var titleText = $('#titleText').val();

    //문자열 "null" 이 들어가는것 방지하기 위해 값이 null 이라면 공백 문자열 대입
    if (titleText == null) {
        titleText = "";
    }
    if (selectKey == null) {
        selectKey == "";
    }

    // 대입 끝

    //url 주소 바꾸기
    const params = {
        page: pageValue,
        selectKey: selectKey,
        titleText: titleText
    }
    const queryString = new URLSearchParams(params).toString();
    const replaceUri = location.pathname + '?' + queryString;
    history.pushState(null, '', replaceUri);
    //url 주소 바꾸기 끝


    var querydata = {
        "page": pageValue,
        "selectKey": selectKey,
        "titleText": titleText
    };


    $.ajax({
        url: "/querydsl",
        data: querydata,
        type: "POST",
    }).done(function (fragment) {
        $("#html_table_lists").replaceWith(fragment);
    });

    $.ajax({
        url: "/paging",
        data: querydata,
        type: "POST",
    }).done(function (fragment) {
        $("#pageList").replaceWith(fragment);
    });
}

//뒤로가면 전 주소값으로 이동하기
window.onpopstate = function (event) {
    console.log("popstate 실행됨");
    $(window).unbind('popstate')
    location.href = document.location;
};


//검색 필드에 단어 입력후 검색버튼 눌렀을 때
function searching() {
    var selectKey = $('#selectKey').val();
    var titleText = $('#titleText').val();

    const params = {
        page: 0,
        selectKey: selectKey,
        titleText: titleText
    }

    const queryString = new URLSearchParams(params).toString();

    const replaceUri = location.pathname + '?' + queryString;


    history.pushState(null, '', replaceUri);
    console.log("replaceUri: " + replaceUri);
    console.log("queryString: " + queryString);

    //값 가져오기 (페이지네이션)
    const myPageQuery = new URLSearchParams(location.search);

    console.log(myPageQuery.get('page'));

    var querydata = {
        "page": myPageQuery.get('page'),
        "selectKey": myPageQuery.get('selectKey'),
        "titleText": myPageQuery.get('titleText')
    };

    $.ajax({
        url: "/querydsl",
        data: querydata,
        type: "POST",
    }).done(function (fragment) {
        $("#html_table_lists").replaceWith(fragment);
    });

    $.ajax({
        url: "/paging",
        data: querydata,
        type: "POST",
    }).done(function (fragment) {
        $("#pageList").replaceWith(fragment);
    });
}

//검색 필드에 단어 입력 후 엔터키 눌렀을 때
function enterkey() {
    if (window.event.keyCode == 13) {
        searching();
    }
}

// 삭제버튼 누르면 모달창으로 경고창 띄운다.
function passValue(obj){
$('#modal-delete').on('show.bs.modal', function(e){
    document.getElementById('modal-delete').setAttribute('name', obj);
    });
}

// 삭제할 것이냐고 경고창 띄웠는데도 삭제누르면 진짜로 삭제해주는 기능
function deletePost(){
    var delete_index = $('#modal-delete').attr('name');
    console.log(delete_index);
    const myPageQuery = new URLSearchParams(location.search);

    var data = {
        "delete_index": delete_index
    };

    $.ajax({
        url: "/delete",
        data: data,
        type: "POST",
        error: function(error){
            swal({
                title: "에러",
                text: "서버 에러로 삭제 실패했습니다.",
                icon: "error" //"info,success,warning,error" 중 택1
            });
        },
        success: function(data){
            searching();
        }
    });
}