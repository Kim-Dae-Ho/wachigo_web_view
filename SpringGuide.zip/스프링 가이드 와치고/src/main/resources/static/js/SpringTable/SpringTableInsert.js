function insert(){
    let writeArray = [];
    const name = $("#name").val();
    const info = $("#info").val();

    const data = {
        'name' : name,
        'info' : info
    };
    writeArray.push(data);
    console.log(writeArray);
    $.ajax({
        url      : "/insert",
        data     : JSON.stringify(writeArray),
        type     : "POST",
        dataType:'text',
        contentType:'application/json;',
        success : function(result) {
            location.href = "/";
        },
        error:function(request,status,error){
            swal({
                text: "서버 문제로 추가하지 못했습니다.",
                icon: "warning" //"info,success,warning,error" 중 택1
            });
        }
    });
}